Your Name

Industrial Designer

123 Your Street

Your City, ST 12345

(123) 456-7890

no_reply@example.com

SKILLS

Lorem ipsum dolor sit amet, consectetuer adipiscing elit, sed diam nonummy nibh euismod tincidunt ut laoreet dolore magna aliquam erat volutpat. 

EXPERIENCE

Company Name,  Location - Job Title

MONTH 20XX - PRESENT

* Lorem ipsum dolor sit amet, consectetur adipiscing elit. 

* Aenean ac interdum nisi. Sed in consequat mi.

Company Name, Location - Job Title

MONTH 20XX - MONTH 20XX

* Lorem ipsum dolor sit amet, consectetur adipiscing elit. 

* Aenean ac interdum nisi. Sed in consequat mi. 

Company Name, Location - Job Title

MONTH 20XX - MONTH 20XX

* Lorem ipsum dolor sit amet, consectetur adipiscing elit. 

* Aenean ac interdum nisi. Sed in consequat mi. 

EDUCATION

School Name, Location - Degree

MONTH 20XX - MONTH 20XX

Lorem ipsum dolor sit amet, consectetuer adipiscing elit, sed diam nonummy nibh euismod tincidunt ut laoreet dolore.

AWARDS

Lorem ipsum dolor sit amet, consectetur adipiscing elit.

Aenean ac interdum nisi.
Test image

1.Open up with greet

2. HI im cirrus, i m a humanoid AI ,how can i help you today
3. What does CL do?
4. Can you me a demo of digital transformation demo => links

5.  Advice on agile/scrum /project management

6. Connect with our team => sales/contact

![image1.jpg](./images/image1.jpg)